import React , { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { FetchWeather } from '../actions/index';

class SearchBar extends Component{

  state = {
    term: '',
  }


inputChangeHandler= (event) =>{
  this.setState({term: event.target.value})
  
}

onFormSubmit = (event) =>{
  event.preventDefault();
  this.props.FetchWeather(this.state.term);
  this.setState({term: ''})

}

render(){
return(
  <form onSubmit={this.onFormSubmit} className="input-group">
    <input className="form-control"
           placeholder="get forecast for your favorite country"
           value={this.state.term}
           onChange={this.inputChangeHandler}
    />
    <span className="input-group-btn">
      <button type="submit" className="btn btn-secondary">submit</button>
    </span>
  </form>
);
}
}

function mapDispatchToProps(dispatch){
  return bindActionCreators({ FetchWeather }, dispatch);
}

export default connect(null ,mapDispatchToProps)(SearchBar);
