# WeatherApp

```
> npm install
> npm start
```
